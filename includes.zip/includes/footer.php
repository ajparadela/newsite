<footer>
			<div class="container">
				<div class="row">
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4 style="color: white">Get in touch with us</h4>
							<address style="color: white">
					<strong >OFC Investment & Property Management</strong><br>
					 <br>
					 </address>
							<p style="color: white">
								<i class="icon-phone"></i> (123) 456-7890 - (123) 555-7891 <br>
								<i class="icon-envelope-alt"></i> email@domainname.com
							</p>
						</div>
					</div>
					<div class="col-sm-3 col-lg-3" >
						<div class="widget">
						<h4 style="color: white">Quick Links</h4>
							<ul class="link-list">
								<li><a href="index.php" style="color: white">Home</a></li>
								<li class="dropdown" style="color: white">
								<a href="#" class="dropdown-toggle " data-toggle="dropdown" data-delay="0" data-close-others="false" style="color: white">Projects &nbsp;<i class="fa fa-angle-down"></i></a>
									<ul class="dropdown-menu">
										<li><a href="propertiesUK.php">Properties in UK</a></li>
										<li><a href="propertiesPH.php">Properties in PH</a></li>
										<li><a href="propertiesHK.php">Properties in HK</a></li>
									</ul>
								</li>
								<li><a href="services.php" style="color: white">Services</a></li>
								<li class="dropdown active" style="color: white">
								<a href="#" class="dropdown-toggle " data-toggle="dropdown" data-delay="0" data-close-others="false" style="color: white">Guide &nbsp;<i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="guideph.php">Clients Information Guide</a></li>
									<li><a href="contactus.php">Contact Us</a></li>
								</ul>

							</li>
								<li><a href="aboutus.php" style="color: white">About Us</a></li>
							</ul>
							
						</div>

					</div>
					<div class="col-sm-3 col-lg-3">
						<div class="widget">
							<h4 style="color: white">Other Websites</h4>
							<ul class="link-list">
								<li><a href="http://lazzyproperty.com/" style="color: white">LAZZYPROPERTY.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3 col-lg-3">
						<div class="widget"><BR><BR><BR><BR><BR><BR><BR><BR>
							<ul class="social-network" >
								<li><a href="#" data-placement="top" title="Facebook" style="color: white"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" data-placement="top" title="Twitter" style="color: white"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" data-placement="top" title="Linkedin" style="color: white"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#" data-placement="top" title="Pinterest" style="color: white"><i class="fa fa-pinterest"></i></a></li>
								<li><a href="#" data-placement="top" title="Google plus" style="color: white"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- <div id="sub-footer">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="copyright">
								<p>&copy; Sailor Theme - All Right Reserved</p>
								<div class="credits">
									
                    All the links in the footer should remain intact. 
                    You can delete the links only if you purchased the pro version.
                    Licensing information: https://bootstrapmade.com/license/
                    Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Sailor
                  
									<a href="https://bootstrapmade.com/bootstrap-business-templates/">Bootstrap Business Templates</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</div> -->
		</footer>
	</div>
	<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

	<!-- Placed at the end of the document so the pages load faster -->
	<script src="js/jquery.min.js"></script>
	<script src="js/modernizr.custom.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="plugins/flexslider/jquery.flexslider-min.js"></script>
	<script src="plugins/flexslider/flexslider.config.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/uisearch.js"></script>
	<script src="js/jquery.cubeportfolio.min.js"></script>
	<script src="js/google-code-prettify/prettify.js"></script>
	<script src="js/animate.js"></script>
	<script src="js/custom.js"></script>


</body>

</html>
