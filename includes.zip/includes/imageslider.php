			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<!-- Slider -->
						<div id="main-slider" class="main-slider flexslider">
							<ul class="slides">
								<li>
									<img src="img/slides/1.jpg" alt="" />
									<div class="flex-caption">
										<h3>BRINGING YOU CLOSER TO YOUR DREAM HOME</h3>
									</div>
								</li>
								<!-- <li>
									<img src="img/slides/2.jpg" alt="" />
									<div class="flex-caption">
										<h3>FIND HAPPINESS IN A NEW HOME.</h3>
									</div>
								</li>
								<li>
									<img src="img/slides/3.jpg" alt="" />
									<div class="flex-caption">
										<h3>OUR PROPERTIES</h3>
									</div>
								</li> -->
							</ul>
						</div>
						<!-- end slider -->

						
					</div>
				</div>
			</div>