<div id="wrapper">
		<!-- start header -->
		<header>
			

			<div class="navbar navbar-default navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
						<a class="navbar-brand" href="index.php"><img src="img/picture1.png" height="145px" style="margin-top: -45px"></a>
 					</div>
					<div class="navbar-collapse collapse ">
						<ul class="nav navbar-nav">
							
							<li><a href="index.php" style="color: white">Home</a></li>
							<li><a href="services.php" style="color: white">Services</a></li>
							<li class="dropdown active" style="color: white">
								<a href="#" class="dropdown-toggle " data-toggle="dropdown" data-delay="0" data-close-others="false" style="color: white">Projects &nbsp;<i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="propertiesUK.php">Properties in UK</a></li>
									<li><a href="propertiesPH.php">Properties in PH</a></li>
									<li><a href="propertiesHK.php">Properties in HK</a></li>
								</ul>

							</li>
							<li class="dropdown active" style="color: white">
								<a href="#" class="dropdown-toggle " data-toggle="dropdown" data-delay="0" data-close-others="false" style="color: white">Guide &nbsp;<i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu">
									<li><a href="guideph.php">Clients Information Guide</a></li>
									<li><a href="contactus.php">Contact Us</a></li>
								</ul>

							</li>
							<li><a href="aboutus.php" style="color: white">About Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</header>