<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="text-center"><!-- 
							<h2>We use <span class="highlight">modern</span> infrastructure & technology</h2> -->
							<h3>Choose one or more house in many of our properties. With each property, having lots to offer, you’re sure to find the perfect place for you and your family. </h3>
						</div>
					</div>
				</div>
			</div>

			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="row">
							<div class="col-sm-4 col-md-4 col-lg-4">
								<div class="box">
									<div class="aligncenter">
										<a href="index.php">
										<div class="icon">
											<i class="fa fa-home fa-5x"></i>
										</div>
										<h4>Home</h4>
										</a>
									</div>
								</div>
							</div>
							<div class="col-sm-4 col-md-4 col-lg-4">
								<div class="box">
									<div class="aligncenter">
										<a href="#">
										<div class="icon">
											<i class="fa fa-building-o fa-5x"></i>
										</div>
										<h4>Our Properties</h4>
										</a>
									</div>
								</div>
							</div>
							<div class="col-sm-4 col-md-4 col-lg-4">
								<div class="box">
									<div class="aligncenter">
										<a href="aboutus.php">
										<div class="icon">
											<i class="fa fa-group fa-5x"></i>
										</div>
										<h4>About Us</h4>
										</a>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>

			<!-- divider -->
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="solidline">
						</div>
					</div>
				</div>
			</div>